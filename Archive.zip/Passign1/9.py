list=[1,2,3,4,5,6]
for i in range(0,len(list)):
    print(list[i],end=" ")
print('')
for i in range(len(list)):
    print(list[i],end=" ")
print('')
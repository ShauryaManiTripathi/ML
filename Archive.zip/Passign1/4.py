items=[1,2,3,4,5,6]
print(items[2:])
items.insert(3,100)
items.append(8)
print(items)
print(f"3rd={items[2]}, 4th={items[3]}, 5th={items[4]}")
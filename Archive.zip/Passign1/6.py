tupple=([1,2,3],2,"hii")
print(f"tupple={tupple}")
tupple=('programming','programming','programming')
tupple=('programming',)*3
print(tupple)
tup1=(1,2,3,4,5)
tup2=(6,)
tup3=tup1+tup2
print(tup3)



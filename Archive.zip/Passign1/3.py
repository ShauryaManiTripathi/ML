sentence = 'I am a computer science student'
print(sentence[0:1])
print(sentence[2:5])
print(sentence[2:])

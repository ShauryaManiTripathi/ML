listt=[1,1,1,2,3,3,4,5,5,5,5]
list2=list(set(listt))
print(list2)





x=11
if x%2==0:
    print('is even')
else:
    print('is odd')
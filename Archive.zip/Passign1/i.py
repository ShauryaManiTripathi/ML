import pandas as pd

# Create today's date
today = pd.Timestamp.today().date()

print(f"Today's date is: {today}")
person = { 'first_name': 'John','last_name': 'Doe','age':25,'favorite_colors': ['blue', 'green'],'active': True}
print(person)
print(person.keys())
print(person.values())
print(person[list(person.keys())[1]])

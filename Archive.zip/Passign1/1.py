x=10
print(x)
y=5
print(x+y)
print(x-y)
print(x*y)
print(x/y)

stringg="123456789"
print(len(stringg))
print(int(stringg))
print(type(int(stringg)))